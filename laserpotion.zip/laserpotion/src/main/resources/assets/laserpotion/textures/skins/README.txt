Buraya oyuncu adiyla skin koy (hepsi kucuk harf):  ismail.png
64x64 skin olmali. Kollar ince (slim) mi kalin mi png'den otomatik anlasilir.
