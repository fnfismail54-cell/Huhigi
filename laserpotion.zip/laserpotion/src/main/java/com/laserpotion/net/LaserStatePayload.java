package com.laserpotion.net;

import com.laserpotion.LaserPotionMod;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;
import net.minecraft.util.Uuids;

import java.util.UUID;

public record LaserStatePayload(UUID player, boolean active) implements CustomPayload {
	public static final CustomPayload.Id<LaserStatePayload> ID =
			new CustomPayload.Id<>(Identifier.of(LaserPotionMod.MOD_ID, "state"));
	public static final PacketCodec<RegistryByteBuf, LaserStatePayload> CODEC = PacketCodec.tuple(
			Uuids.PACKET_CODEC, LaserStatePayload::player,
			PacketCodecs.BOOLEAN, LaserStatePayload::active,
			LaserStatePayload::new);

	@Override public Id<? extends CustomPayload> getId() { return ID; }
}
