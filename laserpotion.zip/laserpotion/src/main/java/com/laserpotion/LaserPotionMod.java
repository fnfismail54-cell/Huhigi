package com.laserpotion;

import com.laserpotion.item.LaserEyeItem;
import com.laserpotion.item.LaserPotionItem;
import com.laserpotion.item.XItem;
import com.laserpotion.net.LaserStatePayload;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;

import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;

public class LaserPotionMod implements ModInitializer {
	public static final String MOD_ID = "laserpotion";
	public static final String TAG = "laserpotion_active";
	/** Sunucuda aktif oyuncular */
	public static final Set<UUID> ACTIVE = ConcurrentHashMap.newKeySet();

	public static Item LASER_POTION;
	public static Item LASER_EYE;
	public static Item X_ITEM;

	private static <T extends Item> T reg(String name, Function<Item.Settings, T> factory) {
		RegistryKey<Item> key = RegistryKey.of(RegistryKeys.ITEM, Identifier.of(MOD_ID, name));
		return Registry.register(Registries.ITEM, key, factory.apply(new Item.Settings().maxCount(1).registryKey(key)));
	}

	@Override
	public void onInitialize() {
		LASER_POTION = reg("laser_potion", LaserPotionItem::new);
		LASER_EYE = reg("laser_eye", LaserEyeItem::new);
		X_ITEM = reg("x_item", XItem::new);

		ItemGroupEvents.modifyEntriesEvent(ItemGroups.FOOD_AND_DRINK).register(e -> e.add(LASER_POTION));
		ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(e -> { e.add(LASER_EYE); e.add(X_ITEM); });

		PayloadTypeRegistry.playS2C().register(LaserStatePayload.ID, LaserStatePayload.CODEC);

		ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
			ServerPlayerEntity p = handler.getPlayer();
			if (p.getCommandTags().contains(TAG)) {
				ACTIVE.add(p.getUuid());
				broadcast(server, p.getUuid(), true);
			}
			for (UUID id : ACTIVE) ServerPlayNetworking.send(p, new LaserStatePayload(id, true));
		});
		ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
			UUID id = handler.getPlayer().getUuid();
			if (ACTIVE.remove(id)) broadcast(server, id, false);
		});
		// Ölünce her şey gider
		ServerPlayerEvents.AFTER_RESPAWN.register((oldP, newP, alive) -> {
			newP.removeCommandTag(TAG);
			if (ACTIVE.remove(newP.getUuid())) broadcast(newP.getServer(), newP.getUuid(), false);
		});
	}

	public static void broadcast(MinecraftServer server, UUID id, boolean active) {
		if (server == null) return;
		LaserStatePayload payload = new LaserStatePayload(id, active);
		for (ServerPlayerEntity pl : PlayerLookup.all(server)) ServerPlayNetworking.send(pl, payload);
	}

	/** İksir içilince */
	public static void activate(ServerPlayerEntity p) {
		int inf = StatusEffectInstance.INFINITE;
		p.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, inf, 1, false, false, true));
		p.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, inf, 1, false, false, true));
		p.addStatusEffect(new StatusEffectInstance(StatusEffects.JUMP_BOOST, inf, 1, false, false, true));
		p.getInventory().offerOrDrop(new ItemStack(LASER_EYE));
		p.getInventory().offerOrDrop(new ItemStack(X_ITEM));
		p.addCommandTag(TAG);
		ACTIVE.add(p.getUuid());
		broadcast(p.getServer(), p.getUuid(), true);
	}

	/** X nesnesi: her şeyi kapat */
	public static void deactivate(ServerPlayerEntity p) {
		p.removeStatusEffect(StatusEffects.REGENERATION);
		p.removeStatusEffect(StatusEffects.SPEED);
		p.removeStatusEffect(StatusEffects.JUMP_BOOST);
		PlayerInventory inv = p.getInventory();
		for (int i = 0; i < inv.size(); i++) {
			ItemStack s = inv.getStack(i);
			if (s.isOf(LASER_EYE) || s.isOf(X_ITEM)) inv.setStack(i, ItemStack.EMPTY);
		}
		p.removeCommandTag(TAG);
		ACTIVE.remove(p.getUuid());
		broadcast(p.getServer(), p.getUuid(), false);
	}
}
