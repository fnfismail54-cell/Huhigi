package com.laserpotion.client;

import com.laserpotion.net.LaserStatePayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;

public class LaserPotionClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		ClientPlayNetworking.registerGlobalReceiver(LaserStatePayload.ID, (payload, ctx) -> {
			if (payload.active()) LaserSkins.ACTIVE.add(payload.player());
			else LaserSkins.ACTIVE.remove(payload.player());
		});
		ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> LaserSkins.ACTIVE.clear());
	}
}
