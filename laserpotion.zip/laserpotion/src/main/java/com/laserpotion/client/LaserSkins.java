package com.laserpotion.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.entity.player.PlayerSkinType;      // 1.21.9+ Yarn: derleme hatası verirse adını düzelt
import net.minecraft.entity.player.SkinTextures;        // 1.21.9+ Yarn: derleme hatası verirse paketini düzelt
import net.minecraft.util.AssetInfo;                    // 1.21.9+ Yarn: derleme hatası verirse paketini düzelt
import net.minecraft.resource.Resource;
import net.minecraft.util.Identifier;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * assets/laserpotion/textures/skins/<oyuncuadı>.png dosyalarına bakar.
 * Dosya varsa o skin; kollar png'den (slim/wide) otomatik anlaşılır.
 * Dosya yoksa Steve skini kullanılır. Her durumda gözler beyaza boyanır.
 */
public final class LaserSkins {
	public static final Set<UUID> ACTIVE = ConcurrentHashMap.newKeySet();
	private static final Map<String, Entry> CACHE = new HashMap<>();
	private record Entry(Identifier tex, boolean slim) {}

	private static final Identifier FALLBACK = Identifier.ofVanilla("textures/entity/player/wide/steve.png");
	private static final int[] EYE_X = {9, 10, 13, 14};
	private static final int[] EYE_Y = {12, 13};

	private LaserSkins() {}

	public static boolean isActive(UUID id) { return ACTIVE.contains(id); }

	public static SkinTextures apply(AbstractClientPlayerEntity player, SkinTextures orig) {
		String name = player.getName().getString().toLowerCase(Locale.ROOT);
		MinecraftClient mc = MinecraftClient.getInstance();
		Identifier src = Identifier.of("laserpotion", "textures/skins/" + name + ".png");
		boolean hasFile = mc.getResourceManager().getResource(src).isPresent();
		String key = hasFile ? name : "_fallback";
		Entry e = CACHE.computeIfAbsent(key, k -> build(mc, k, hasFile ? src : FALLBACK));
		if (e == null) return null;

		PlayerSkinType model = e.slim() ? PlayerSkinType.SLIM : PlayerSkinType.WIDE;
		AssetInfo.TextureAssetInfo body = new AssetInfo.TextureAssetInfo(e.tex(), e.tex());
		return new SkinTextures(body, orig.cape(), orig.elytra(), model, orig.secure());
	}

	private static Entry build(MinecraftClient mc, String key, Identifier src) {
		try {
			Optional<Resource> r = mc.getResourceManager().getResource(src);
			if (r.isEmpty()) return null;
			try (InputStream in = r.get().getInputStream(); NativeImage img = NativeImage.read(in)) {
				// ince kol: sağ kolun arka yüzü (x=54..55, y=20..31) şeffaf kalır
				boolean slim = img.getHeight() >= 64
						&& (img.getColorArgb(54, 20) >>> 24) == 0
						&& (img.getColorArgb(55, 20) >>> 24) == 0;
				NativeImage copy = new NativeImage(img.getWidth(), img.getHeight(), true);
				copy.copyFrom(img);
				for (int x : EYE_X) for (int y : EYE_Y) copy.setColorArgb(x, y, 0xFFFFFFFF);
				Identifier id = Identifier.of("laserpotion", "dynamic/" + key);
				mc.getTextureManager().registerTexture(id,
						new NativeImageBackedTexture(() -> "laserpotion_" + key, copy));
				return new Entry(id, slim);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}
}
