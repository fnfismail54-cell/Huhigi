package com.laserpotion.item;

import com.laserpotion.LaserPotionMod;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsage;
import net.minecraft.item.Items;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.UseAction;
import net.minecraft.world.World;

public class LaserPotionItem extends Item {
	public LaserPotionItem(Settings settings) { super(settings); }

	@Override public UseAction getUseAction(ItemStack stack) { return UseAction.DRINK; }
	@Override public int getMaxUseTime(ItemStack stack, LivingEntity user) { return 32; }

	@Override
	public ActionResult use(World world, PlayerEntity user, Hand hand) {
		return ItemUsage.consumeHeldItem(world, user, hand);
	}

	@Override
	public ItemStack finishUsing(ItemStack stack, World world, LivingEntity user) {
		if (user instanceof ServerPlayerEntity sp) LaserPotionMod.activate(sp);
		if (user instanceof PlayerEntity pl && !pl.isCreative()) {
			stack.decrement(1);
			ItemStack bottle = new ItemStack(Items.GLASS_BOTTLE); // içecek boşalır
			if (stack.isEmpty()) return bottle;
			pl.getInventory().offerOrDrop(bottle);
		}
		return stack;
	}
}
