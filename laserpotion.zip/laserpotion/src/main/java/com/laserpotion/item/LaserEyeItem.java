package com.laserpotion.item;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.UseAction;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

public class LaserEyeItem extends Item {
	private static final double RANGE = 48.0;
	private static final DustParticleEffect BLUE = new DustParticleEffect(0x2255FF, 1.3f);

	public LaserEyeItem(Settings settings) { super(settings); }

	@Override public UseAction getUseAction(ItemStack stack) { return UseAction.NONE; }
	@Override public int getMaxUseTime(ItemStack stack, LivingEntity user) { return 72000; }

	@Override
	public ActionResult use(World world, PlayerEntity user, Hand hand) {
		user.setCurrentHand(hand);
		return ActionResult.CONSUME;
	}

	@Override
	public void usageTick(World world, LivingEntity user, ItemStack stack, int remainingUseTicks) {
		if (!(world instanceof ServerWorld sw)) return;

		Vec3d eye = user.getEyePos();
		Vec3d look = user.getRotationVec(1.0f);
		Vec3d end = eye.add(look.multiply(RANGE));

		BlockHitResult bhit = sw.raycast(new RaycastContext(eye, end,
				RaycastContext.ShapeType.OUTLINE, RaycastContext.FluidHandling.NONE, user));
		Vec3d stop = bhit.getType() == HitResult.Type.MISS ? end : bhit.getPos();
		double dist = eye.distanceTo(stop);

		Box box = user.getBoundingBox().stretch(look.multiply(dist)).expand(1.0);
		EntityHitResult ehit = ProjectileUtil.raycast(user, eye, stop, box,
				e -> !e.isSpectator() && e.canHit(), dist * dist);
		if (ehit != null) {
			Entity target = ehit.getEntity();
			stop = ehit.getPos();
			target.damage(sw, sw.getDamageSources().indirectMagic(user, user), 2.0f);
			target.setOnFireFor(2);
		}

		Vec3d start = eye.add(look.multiply(0.5)).add(0, -0.1, 0);
		Vec3d dir = stop.subtract(start);
		double len = dir.length();
		if (len < 0.1) return;
		dir = dir.multiply(1.0 / len);
		for (double t = 0; t < len; t += 0.35) {
			Vec3d p = start.add(dir.multiply(t));
			sw.spawnParticles(BLUE, p.x, p.y, p.z, 1, 0, 0, 0, 0);
		}
	}
}
