package com.laserpotion.item;

import com.laserpotion.LaserPotionMod;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.world.World;

public class XItem extends Item {
	public XItem(Settings settings) { super(settings); }

	@Override
	public ActionResult use(World world, PlayerEntity user, Hand hand) {
		if (user instanceof ServerPlayerEntity sp) LaserPotionMod.deactivate(sp);
		return ActionResult.SUCCESS;
	}
}
