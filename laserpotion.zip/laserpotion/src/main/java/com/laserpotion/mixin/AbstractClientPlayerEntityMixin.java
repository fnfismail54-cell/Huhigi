package com.laserpotion.mixin;

import com.laserpotion.client.LaserSkins;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.player.SkinTextures;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(AbstractClientPlayerEntity.class)
public abstract class AbstractClientPlayerEntityMixin {
	// 1.21.9+ Yarn'da getSkin(); eski adı getSkinTextures()
	@Inject(method = "getSkin", at = @At("RETURN"), cancellable = true)
	private void laserpotion$skin(CallbackInfoReturnable<SkinTextures> cir) {
		AbstractClientPlayerEntity self = (AbstractClientPlayerEntity) (Object) this;
		if (!LaserSkins.isActive(self.getUuid())) return;
		SkinTextures r = LaserSkins.apply(self, cir.getReturnValue());
		if (r != null) cir.setReturnValue(r);
	}
}
